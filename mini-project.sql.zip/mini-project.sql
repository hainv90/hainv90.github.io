-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Máy chủ: localhost:3306
-- Thời gian đã tạo: Th7 16, 2021 lúc 09:24 AM
-- Phiên bản máy phục vụ: 5.7.24
-- Phiên bản PHP: 7.2.19

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Cơ sở dữ liệu: `mini-project`
--

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `categories`
--

CREATE TABLE `categories` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `parent_id` int(11) NOT NULL DEFAULT '0',
  `is_home` tinyint(1) NOT NULL DEFAULT '0',
  `meta_title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_desc` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_keyword` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `categories`
--

INSERT INTO `categories` (`id`, `name`, `slug`, `parent_id`, `is_home`, `meta_title`, `meta_desc`, `meta_keyword`, `created_at`, `updated_at`) VALUES
(2, 'Lester Cronin Jr.', 'Lester Cronin Jr.', 0, 1, 'Dr.', '0', '0', '2020-12-01 03:29:49', '2021-03-24 21:53:23'),
(3, 'Kamryn Orn', 'accusantium-repellat-voluptatibus-minus-blanditiis-tenetur', 0, 0, 'Mr.', '', '', '2020-12-01 03:29:49', '2020-12-01 03:29:49'),
(4, 'Henderson Nitzsche', 'in-iusto-ratione-quas-a-dolorem-culpa-ea', 0, 0, 'Dr.', '', '', '2020-12-01 03:29:49', '2020-12-01 03:29:49'),
(5, 'Garnett Hand', 'ad-blanditiis-nihil-sunt-sed-quia-ullam-quaerat-et', 0, 0, 'Prof.', '', '', '2020-12-01 03:29:49', '2020-12-01 03:29:49'),
(6, 'Dalton Dach', 'nihil-consequatur-quo-eligendi-cum-voluptas-molestiae-et', 0, 0, 'Prof.', '', '', '2020-12-01 03:29:49', '2020-12-01 03:29:49'),
(7, 'Tremayne Steuber', 'inventore-maxime-voluptate-inventore-et-illum-omnis-ex', 0, 0, 'Mr.', '', '', '2020-12-01 03:29:49', '2020-12-01 03:29:49'),
(8, 'Kirsten Swaniawski sky', 'Kirsten Swaniawski sky', 0, 1, 'Prof.', NULL, NULL, '2020-12-01 03:29:49', '2021-03-22 02:35:27'),
(9, 'Mr. Isaiah Hackett III', 'cumque-dolor-dolores-nisi-corrupti', 0, 0, 'Mrs.', '', '', '2020-12-01 03:29:49', '2020-12-01 03:29:49'),
(10, 'Sigmund Cole III', 'aut-et-quo-tempore-qui', 0, 0, 'Miss', '', '', '2020-12-01 03:29:49', '2020-12-01 03:29:49'),
(11, 'Mobile', 'mobile', 0, 1, 'moblie', 'moblie', 'moblie', '2021-03-23 01:50:11', '2021-03-23 01:50:11'),
(12, 'Laptop', 'laptop', 0, 1, '0', '0', '0', '2021-03-23 01:54:04', '2021-03-23 01:54:04'),
(13, 'Desktop', 'desktop', 0, 0, '0', '0', '0', '2021-03-23 02:53:28', '2021-03-23 02:53:28'),
(14, 'printer', 'printer', 0, 1, '0', '0', '0', '2021-03-23 02:58:14', '2021-03-23 02:58:14'),
(18, 'Apple 3', 'Apple 3', 11, 1, 'apple', 'apple', 'apple', '2021-03-30 20:47:12', '2021-03-30 20:48:57'),
(19, 'Dell', 'Dell', 12, 1, 'dell', 'dell', 'dell', '2021-04-06 03:18:59', '2021-04-06 03:18:59'),
(20, 'Apple', 'Apple', 11, 1, 'apple', 'apple', 'apple', '2021-04-06 03:54:21', '2021-04-06 20:56:49'),
(21, 'Aus', 'asus', 0, 1, 'asus', 'asus', 'asus', '2021-04-06 20:57:55', '2021-04-06 20:57:55');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `category_product`
--

CREATE TABLE `category_product` (
  `category_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `category_product`
--

INSERT INTO `category_product` (`category_id`, `product_id`, `created_at`, `updated_at`) VALUES
(8, 1, NULL, NULL),
(10, 2, NULL, NULL),
(8, 3, NULL, NULL),
(5, 4, NULL, NULL),
(5, 5, NULL, NULL),
(6, 6, NULL, NULL),
(9, 7, NULL, NULL),
(10, 8, NULL, NULL),
(4, 9, NULL, NULL),
(2, 10, NULL, NULL),
(9, 11, NULL, NULL),
(3, 12, NULL, NULL),
(9, 13, NULL, NULL),
(5, 14, NULL, NULL),
(1, 15, NULL, NULL),
(9, 16, NULL, NULL),
(4, 17, NULL, NULL),
(7, 18, NULL, NULL),
(5, 19, NULL, NULL),
(10, 20, NULL, NULL),
(6, 21, NULL, NULL),
(5, 22, NULL, NULL),
(1, 23, NULL, NULL),
(2, 24, NULL, NULL),
(10, 25, NULL, NULL),
(1, 26, NULL, NULL),
(10, 27, NULL, NULL),
(8, 28, NULL, NULL),
(7, 29, NULL, NULL),
(4, 30, NULL, NULL),
(3, 31, NULL, NULL),
(2, 32, NULL, NULL),
(9, 33, NULL, NULL),
(10, 34, NULL, NULL),
(3, 35, NULL, NULL),
(7, 36, NULL, NULL),
(6, 37, NULL, NULL),
(5, 38, NULL, NULL),
(10, 39, NULL, NULL),
(1, 40, NULL, NULL),
(4, 41, NULL, NULL),
(10, 42, NULL, NULL),
(2, 43, NULL, NULL),
(8, 44, NULL, NULL),
(4, 45, NULL, NULL),
(4, 46, NULL, NULL),
(10, 47, NULL, NULL),
(8, 48, NULL, NULL),
(3, 49, NULL, NULL),
(5, 50, NULL, NULL),
(1, 53, NULL, NULL),
(2, 53, NULL, NULL),
(1, 54, NULL, NULL),
(2, 54, NULL, NULL),
(11, 55, NULL, NULL),
(11, 56, NULL, NULL),
(0, 57, NULL, NULL),
(11, 58, NULL, NULL),
(5, 59, NULL, NULL),
(4, 59, NULL, NULL),
(5, 60, NULL, NULL),
(6, 60, NULL, NULL),
(5, 61, NULL, NULL),
(3, 61, NULL, NULL);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(67, '2014_10_12_000000_create_users_table', 1),
(68, '2014_10_12_100000_create_password_resets_table', 1),
(69, '2019_08_19_000000_create_failed_jobs_table', 1),
(70, '2020_08_21_062510_create_categories_table', 1),
(71, '2020_08_21_063013_create_products_table', 1),
(72, '2020_08_21_063600_create_product_images_table', 1),
(73, '2020_09_15_075404_create_category_product_table', 1),
(74, '2020_11_04_092915_create_posts_table', 1),
(75, '2020_11_27_092221_create_orders_table', 1);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `orders`
--

CREATE TABLE `orders` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `posts`
--

CREATE TABLE `posts` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_home` tinyint(1) NOT NULL DEFAULT '0',
  `content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `meta_title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_desc` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_keyword` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `products`
--

CREATE TABLE `products` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` double(8,2) NOT NULL DEFAULT '0.00',
  `sale_price` double(8,2) NOT NULL DEFAULT '0.00',
  `image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_desc` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_keyword` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `products`
--

INSERT INTO `products` (`id`, `name`, `slug`, `price`, `sale_price`, `image`, `meta_title`, `meta_desc`, `meta_keyword`, `created_at`, `updated_at`) VALUES
(3, 'Mrs. Elvie Fahey PhD 3', 'Mrs. Elvie Fahey PhD 3', 1309.00, 60292.00, '0', 'Prof.', '0', '0', '2020-12-01 03:31:01', '2021-03-30 08:15:55'),
(4, 'Irwin Wisozk', 'alias-nihil-harum-a-est', 20738.00, 74429.00, 'public\\uploads\\images\\e76bed3ea6d87e2bd53e3b4ebcda68a7.jpg', 'Prof.', '', '', '2020-12-01 03:31:01', '2020-12-01 03:31:01'),
(5, 'Daisha Schmeler', 'atque-possimus-quaerat-ratione-dolor', 28701.00, 72294.00, 'public\\uploads\\images\\5253e99c145f1dc4477e8a8f0a23b2da.jpg', 'Mrs.', '', '', '2020-12-01 03:31:01', '2020-12-01 03:31:01'),
(6, 'Adrien Quigley', 'exercitationem-omnis-voluptatem-vel-mollitia-et-ut-consequatur', 78556.00, 73186.00, 'public\\uploads\\images\\8eb9b524bca4003f3026705271e9bd12.jpg', 'Ms.', '', '', '2020-12-01 03:31:01', '2020-12-01 03:31:01'),
(7, 'Mrs. Susan Jaskolski III', 'Mrs. Susan Jaskolski III', 17423.00, 25680.00, '0', 'Mrs.', '0', '0', '2020-12-01 03:31:01', '2021-03-30 08:15:34'),
(8, 'Prof. Shaylee Jakubowski Sr.', 'et-aut-molestiae-consequatur-labore', 28327.00, 67727.00, 'public\\uploads\\images\\5463beeb3d5e71e68013c8d795f979ef.jpg', 'Mrs.', '', '', '2020-12-01 03:31:01', '2020-12-01 03:31:01'),
(9, 'Emmalee Reichel', 'et-ut-aut-veniam-velit', 13930.00, 91949.00, 'public\\uploads\\images\\66e1bef99258db56f9bbba6ad29a512e.jpg', 'Mrs.', '', '', '2020-12-01 03:31:01', '2020-12-01 03:31:01'),
(10, 'Ms. Leola Nikolaus V', 'eligendi-qui-sed-consequuntur-aut-voluptatem-ut-voluptas', 70168.00, 10839.00, 'public\\uploads\\images\\39c881f0ebb9728ded197e99bed1722d.jpg', 'Dr.', '', '', '2020-12-01 03:31:01', '2020-12-01 03:31:01'),
(11, 'Miss Tess Hahn', 'delectus-praesentium-quasi-et-sed', 60346.00, 37966.00, 'public\\uploads\\images\\1a352084d44ea9eb0b5f6658d5d0779b.jpg', 'Mr.', '', '', '2020-12-01 03:31:01', '2020-12-01 03:31:01'),
(12, 'Dr. Julius Halvorson', 'adipisci-doloremque-consequuntur-aspernatur-dolore-inventore-ab', 34543.00, 47536.00, 'public\\uploads\\images\\02f174004dcf5e6c4248121b91528c33.jpg', 'Miss', '', '', '2020-12-01 03:31:01', '2020-12-01 03:31:01'),
(13, 'River Block', 'aut-quae-velit-est-accusantium-necessitatibus-est', 19901.00, 88782.00, 'public\\uploads\\images\\dbf22c31d0c608cbb92fbe80d776720c.jpg', 'Mr.', '', '', '2020-12-01 03:31:01', '2020-12-01 03:31:01'),
(14, 'Dr. Belle Larson', 'dolorum-iste-voluptatibus-dolor-earum', 73906.00, 52292.00, 'public\\uploads\\images\\c3e9fd9b4027537e0daf653126dffd19.jpg', 'Mr.', '', '', '2020-12-01 03:31:01', '2020-12-01 03:31:01'),
(15, 'Dr. Adolfo Mante DDS', 'enim-ea-sed-voluptatibus', 32992.00, 28743.00, 'public\\uploads\\images\\9c4e913f21980ebc1248c98212cee319.jpg', 'Ms.', '', '', '2020-12-01 03:31:01', '2020-12-01 03:31:01'),
(16, 'Dr. Leda Kemmer', 'ipsa-molestiae-voluptatum-impedit-commodi', 59848.00, 9658.00, 'public\\uploads\\images\\ed7ecbed91b00e816dafd2ce3c650875.jpg', 'Miss', '', '', '2020-12-01 03:31:01', '2020-12-01 03:31:01'),
(17, 'Elisa Ondricka', 'aut-numquam-totam-aut-blanditiis-ullam-vero-adipisci-officiis', 58136.00, 45825.00, 'public\\uploads\\images\\9ff9e5d732314ef5900334bfd7b90bfe.jpg', 'Dr.', '', '', '2020-12-01 03:31:01', '2020-12-01 03:31:01'),
(18, 'Dr. Billy Koelpin III', 'cum-accusamus-molestias-recusandae-maiores', 99855.00, 86697.00, 'public\\uploads\\images\\06504f19caf8a2dfe7ce40baa70ddc9e.jpg', 'Ms.', '', '', '2020-12-01 03:31:01', '2020-12-01 03:31:01'),
(19, 'Chance Simonis', 'reprehenderit-quod-et-sed-est', 77646.00, 6166.00, 'public\\uploads\\images\\7de60bc7503df559a9e2e1b660fab007.jpg', 'Dr.', '', '', '2020-12-01 03:31:01', '2020-12-01 03:31:01'),
(20, 'Alyson Spencer', 'vel-omnis-omnis-consequatur-cupiditate-quibusdam', 30868.00, 83114.00, 'public\\uploads\\images\\185d36f7d38f514fe86c7e1e1f870fcc.jpg', 'Mrs.', '', '', '2020-12-01 03:31:01', '2020-12-01 03:31:01'),
(21, 'Verdie Lindgren', 'laudantium-eveniet-quia-ut-pariatur-corrupti', 56600.00, 85138.00, 'public\\uploads\\images\\13c04c26aa79a3c506269bf1cb2cc4ac.jpg', 'Prof.', '', '', '2020-12-01 03:31:01', '2020-12-01 03:31:01'),
(22, 'Dr. Dameon Wisozk', 'qui-itaque-illum-veritatis-at', 12025.00, 55204.00, 'public\\uploads\\images\\80920a61036bcca8460e6020b4684ca3.jpg', 'Prof.', '', '', '2020-12-01 03:31:01', '2020-12-01 03:31:01'),
(23, 'Camylle Ruecker', 'enim-qui-id-ut-deleniti-esse-consequatur', 23847.00, 77335.00, 'public\\uploads\\images\\3d1d9799ad0be6756d08719a0dc7e3ee.jpg', 'Mrs.', '', '', '2020-12-01 03:31:01', '2020-12-01 03:31:01'),
(24, 'Camilla Reynolds', 'rerum-adipisci-eligendi-deleniti-dolor-sed-incidunt-deserunt', 85885.00, 18693.00, 'public\\uploads\\images\\265d9791f8954c5db666bf5f9b1cacf1.jpg', 'Prof.', '', '', '2020-12-01 03:31:01', '2020-12-01 03:31:01'),
(25, 'Rupert Cormier V', 'laboriosam-pariatur-voluptas-officia', 97867.00, 28156.00, 'public\\uploads\\images\\5e8dfad17f1c4b78e748e0a4ebc994fc.jpg', 'Dr.', '', '', '2020-12-01 03:31:01', '2020-12-01 03:31:01'),
(26, 'Darron Walker', 'quidem-et-eligendi-autem-animi-modi-exercitationem-veritatis', 22869.00, 32380.00, 'public\\uploads\\images\\db2464776d38830b3299ccafacf9ed96.jpg', 'Prof.', '', '', '2020-12-01 03:31:01', '2020-12-01 03:31:01'),
(27, 'Oral Hamill Sr.', 'molestiae-praesentium-quidem-cupiditate-vel-aperiam', 48167.00, 56550.00, 'public\\uploads\\images\\2ad506ae6735331fb030d82bfbe01805.jpg', 'Miss', '', '', '2020-12-01 03:31:01', '2020-12-01 03:31:01'),
(28, 'Oda Howe', 'ea-nihil-et-sit', 71722.00, 75972.00, 'public\\uploads\\images\\5e47a7ce4fc10d8ffe49f8663fb19872.jpg', 'Mrs.', '', '', '2020-12-01 03:31:01', '2020-12-01 03:31:01'),
(29, 'Prof. Freeda Stroman', 'laboriosam-quos-et-est', 92487.00, 54118.00, 'public\\uploads\\images\\ce6c44aadd3b5df11159685d42cc8c08.jpg', 'Ms.', '', '', '2020-12-01 03:31:01', '2020-12-01 03:31:01'),
(30, 'Kamryn Lakin III', 'velit-iure-harum-consequatur-at', 1572.00, 87978.00, 'public\\uploads\\images\\476a319af47c20c5ec00a6905a07f3a2.jpg', 'Mrs.', '', '', '2020-12-01 03:31:01', '2020-12-01 03:31:01'),
(31, 'Destany Stanton', 'nemo-aperiam-laudantium-tempore-quisquam', 16831.00, 85686.00, 'public\\uploads\\images\\623140c6646776ca54c1c55b6c181175.jpg', 'Mrs.', '', '', '2020-12-01 03:31:01', '2020-12-01 03:31:01'),
(32, 'Susana Robel DVM', 'laudantium-reprehenderit-aut-vitae-tempora-ipsum-vel-veniam', 7342.00, 85373.00, 'public\\uploads\\images\\2c4d696a23e0dc7c55d5429432e2f931.jpg', 'Prof.', '', '', '2020-12-01 03:31:01', '2020-12-01 03:31:01'),
(33, 'Beaulah Zieme', 'enim-voluptas-sequi-temporibus-necessitatibus', 66241.00, 52361.00, 'public\\uploads\\images\\387074f06c726990749d9faf53110db3.jpg', 'Prof.', '', '', '2020-12-01 03:31:01', '2020-12-01 03:31:01'),
(34, 'Laney Conroy', 'iure-molestias-quae-qui-blanditiis-facere-dolorem-accusantium-magnam', 79242.00, 58706.00, 'public\\uploads\\images\\ee707bd56e98a8f0839628f9bdcfc69a.jpg', 'Prof.', '', '', '2020-12-01 03:31:01', '2020-12-01 03:31:01'),
(35, 'Reina Nicolas', 'quaerat-est-necessitatibus-sit-atque-minus', 63790.00, 31348.00, 'public\\uploads\\images\\22411285981349219f3e1a3c60738cc4.jpg', 'Dr.', '', '', '2020-12-01 03:31:01', '2020-12-01 03:31:01'),
(36, 'Mr. Rodger Hyatt', 'rerum-ratione-praesentium-ut-veritatis-sunt-quas-harum', 93011.00, 61222.00, 'public\\uploads\\images\\31ffd4abd740e0b906df457f6857a656.jpg', 'Mr.', '', '', '2020-12-01 03:31:01', '2020-12-01 03:31:01'),
(37, 'Benton Goyette IV', 'non-autem-laboriosam-ullam', 66044.00, 51212.00, 'public\\uploads\\images\\f419c8b71d0873256109abf740139441.jpg', 'Prof.', '', '', '2020-12-01 03:31:01', '2020-12-01 03:31:01'),
(38, 'Percy Harvey', 'cum-sunt-similique-quis-error-ut', 86984.00, 42011.00, 'public\\uploads\\images\\caceff1ca3e25ec0b8f9bfce313c0154.jpg', 'Ms.', '', '', '2020-12-01 03:31:01', '2020-12-01 03:31:01'),
(39, 'Deontae Harber', 'autem-magni-laudantium-molestiae-exercitationem-sint-laborum-labore', 42041.00, 78812.00, 'public\\uploads\\images\\9e63eebc798e37249a64238efeb69f58.jpg', 'Prof.', '', '', '2020-12-01 03:31:01', '2020-12-01 03:31:01'),
(40, 'Mr. Coleman Moen MD', 'fugit-sunt-nesciunt-vel-qui-est-voluptas-suscipit-est', 99036.00, 97240.00, 'public\\uploads\\images\\d2efe7ac1e99607eb2dfe6015dc94a21.jpg', 'Dr.', '', '', '2020-12-01 03:31:01', '2020-12-01 03:31:01'),
(41, 'Vickie Hudson II', 'est-qui-est-fugit-sit-aut-repudiandae-dolores', 80272.00, 69470.00, 'public\\uploads\\images\\5c149c21fbf1408f4ad18e59a1f37ba0.jpg', 'Prof.', '', '', '2020-12-01 03:31:01', '2020-12-01 03:31:01'),
(42, 'Willow Cremin', 'dolorem-soluta-quae-aperiam-reprehenderit', 28352.00, 9438.00, 'public\\uploads\\images\\e265e5f47b3e89978df3ae199b6da2e7.jpg', 'Mrs.', '', '', '2020-12-01 03:31:01', '2020-12-01 03:31:01'),
(43, 'Dr. Davonte Pollich', 'cumque-ad-non-illo-et-id', 97562.00, 27120.00, 'public\\uploads\\images\\ce88d50961b320fd5aaec7286d0f5861.jpg', 'Mr.', '', '', '2020-12-01 03:31:01', '2020-12-01 03:31:01'),
(44, 'Edmund Schmidt', 'rerum-delectus-nemo-architecto-dolorem-velit-voluptate-iste', 12205.00, 90044.00, 'public\\uploads\\images\\37256a4fbd248e24cb1d9f83308759d5.jpg', 'Mrs.', '', '', '2020-12-01 03:31:01', '2020-12-01 03:31:01'),
(45, 'Zelda Harris', 'eos-maxime-labore-ducimus-nisi-sapiente-ut-eos', 73887.00, 83357.00, 'public\\uploads\\images\\eedd2dbd02f8ce8291bf8e43d9c65072.jpg', 'Prof.', '', '', '2020-12-01 03:31:01', '2020-12-01 03:31:01'),
(46, 'Chadrick Mueller II', 'et-voluptates-architecto-minima-velit-aut-quisquam', 28506.00, 21964.00, 'public\\uploads\\images\\5f708e30d367ecfa30c911cba58f3e9e.jpg', 'Ms.', '', '', '2020-12-01 03:31:01', '2020-12-01 03:31:01'),
(47, 'Prof. Rollin Orn V', 'omnis-deleniti-et-et-doloremque', 91607.00, 31254.00, 'public\\uploads\\images\\f159bd762acafd3693c589a0ae952322.jpg', 'Mrs.', '', '', '2020-12-01 03:31:01', '2020-12-01 03:31:01'),
(48, 'Sigurd McDermott', 'molestias-necessitatibus-voluptas-facilis-officiis-perferendis', 34639.00, 4121.00, 'public\\uploads\\images\\8755ac609251ad0f9a4e180cc1396038.jpg', 'Mr.', '', '', '2020-12-01 03:31:01', '2020-12-01 03:31:01'),
(49, 'Marquise Sauer', 'soluta-est-magnam-dolore-magnam-in-eum-ex', 3874.00, 33884.00, 'public\\uploads\\images\\f32fbf50006e21b6a5be5250ff940cfe.jpg', 'Miss', '', '', '2020-12-01 03:31:01', '2020-12-01 03:31:01'),
(50, 'Prof. Alene Bogan III', 'accusantium-recusandae-amet-ipsam-rerum', 35819.00, 68487.00, 'public\\uploads\\images\\42e822345617b2ab1f9b3ebdb24e38ad.jpg', 'Ms.', '', '', '2020-12-01 03:31:01', '2020-12-01 03:31:01'),
(51, 'Thời trang nam', 'thoi-trang-nam', 0.00, 0.00, NULL, 'thoi trang nam', 'thoi trang nam', 'thoi trang nam', '2020-12-01 20:25:07', '2020-12-01 20:25:07'),
(53, 'Thời trang tre em', 'thoi-trang-tre-em', 1000.00, 0.00, '0', 'thoi trang tre em', 'thoi trang tre em', 'thoi trang tre em', '2020-12-04 21:55:59', '2020-12-04 21:55:59'),
(54, 'Thời trang nu', 'thoi-trang-nu', 1000.00, 0.00, '0', 'thoi trang nu', 'thoi trang nu', 'thoi trang nu', '2020-12-04 21:56:26', '2020-12-04 21:56:26'),
(55, 'test để xoa', 'test', 0.00, 0.00, '0', NULL, NULL, NULL, '2021-04-08 01:49:42', '2021-04-08 02:02:26');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `product_images`
--

CREATE TABLE `product_images` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `avatar` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `gender` int(11) NOT NULL DEFAULT '0',
  `address` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `remember_token` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email_verified_at` datetime DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `avatar`, `phone`, `gender`, `address`, `remember_token`, `email_verified_at`, `created_at`, `updated_at`) VALUES
(1, 'Prof. Maynard Schamberger', 'vdaugherty@example.org', '$2y$10$fOsJc.pbNq5g7NuRlB1kte8IKjIME5OS9NyRGxRB2BDKIKC5b6cYG', '', '096388898', 1, 'Hà Nội', 'jA5pU3zHES', NULL, '2020-12-01 03:29:49', '2020-12-01 03:29:49'),
(2, 'Deondre Wolff II', 'beahan.vella@example.org', '$2y$10$iecL4FoGCWqI3zQ6JvJq/elyQ1Gr3nLAvIv8HsAynVBPMakqKGoGi', '', '096388898', 1, 'Hà Nội', 'V1BBt3mqv2', NULL, '2020-12-01 03:29:49', '2020-12-01 03:29:49'),
(3, 'Mathilde DuBuque', 'magdalen.hodkiewicz@example.org', '$2y$10$5TVMe/msX7/V8.ycAMPpPOmU8tsl8Tjw79YSjYceE9fZd9neI5g0e', '', '096388898', 1, 'Hà Nội', 'xC9RjZfiFS', NULL, '2020-12-01 03:29:49', '2020-12-01 03:29:49'),
(4, 'Lê Văn Lý', 'lely@gmail.com', 'eyJpdiI6ImdKTnNWV1BHeUE4a0pXQjRKOE5ZK3c9PSIsInZhbHVlIjoiZ2s1MWoydkFHR091TlpENEJINWdTZEh2bFQ4U25WNVFLN3hiSTBhclRsOD0iLCJtYWMiOiIxOGU5NzU2ODZjNjIwYTc5ZjU2YzA4MGY3OWMyNDFkY2RhNjkzMjk3N2ZiY2Y1N2ViZTE0ZDkwNjg0NDEwYTA2In0=', '', '012345678', 1, 'Hà Nội', 'CMOw9XSckM', NULL, '2020-12-01 03:29:49', '2020-12-05 03:19:07'),
(5, 'Prof. Max Schulist IV', 'okuneva.benny@example.org', '$2y$10$pmW96bwhox8St2pL8WSVeeHXPAlFv7Gj9qFbFuiLGNxk0sHkF2d1O', '', '096388898', 1, 'Hà Nội', 'adtXDrYcsT', NULL, '2020-12-01 03:29:49', '2020-12-01 03:29:49'),
(6, 'Clara Jacobs', 'hagenes.evert@example.com', '$2y$10$C0K7hu4YX2AozJGBBkUaU.5pigJSBWlLNdHXrp9voFUz468.Xzjjm', '', '096388898', 1, 'Hà Nội', 'hP1ujWARrC', NULL, '2020-12-01 03:29:49', '2020-12-01 03:29:49'),
(7, 'Ed Koepp', 'mcglynn.mathias@example.net', '$2y$10$9CKQX2VJXK4aCRNRv9.3juMW9AaiG72KgkRBBxeSImOG8sJu3bIXG', '', '096388898', 1, 'Hà Nội', 'rWfk3AeJib', NULL, '2020-12-01 03:29:49', '2020-12-01 03:29:49'),
(8, 'Dr. Rosendo Jaskolski', 'reese78@example.com', '$2y$10$gXdTXrg/CXsjH6fXirz3zuou8JpdfGp4KBoMxnj/cSyUSR.94Hn5G', '', '096388898', 1, 'Hà Nội', 'quO8g34cHz', NULL, '2020-12-01 03:29:49', '2020-12-01 03:29:49'),
(9, 'Benjamin Dickinson', 'mueller.zetta@example.org', '$2y$10$Ior/F/8C3rKsEdSg3QfQhOdWZRTiI.P7adOf0zpIChjS8/h8AVOvm', '', '096388898', 1, 'Hà Nội', '8A5jPKu9D8', NULL, '2020-12-01 03:29:49', '2020-12-01 03:29:49'),
(10, 'Angeline Ebert', 'rosa40@example.net', '$2y$10$vL.EF/qAvHzSvzbHhr0W7On9BbvkNzUaZ/eFMAEm2r/nq4Rg7TYeG', '', '096388898', 1, 'Hà Nội', 'xSncF0zMxy', NULL, '2020-12-01 03:29:49', '2020-12-01 03:29:49'),
(11, 'Ms. Hettie Daniel II', 'owest@example.net', '$2y$10$JzcVJ./3idoAtTm67PJeEuKmwztsKqmOSnCNj3UVGaa9L5KMQVz3G', '', '096388898', 1, 'Hà Nội', '2MOMMP16xK', NULL, '2020-12-01 03:29:49', '2020-12-01 03:29:49'),
(12, 'Fleta Harber', 'rowe.casey@example.org', '$2y$10$XymK7xpahJSSiePB79hI1.qHVeUpXIMn3.ddJ6ogDbo.mvaL9/xHi', '', '096388898', 1, 'Hà Nội', 'd7A1wfkATw', NULL, '2020-12-01 03:29:49', '2020-12-01 03:29:49'),
(13, 'Sydnee Powlowski IV', 'reynolds.jayne@example.org', '$2y$10$9sNm.VEeHuWwMPJJTWqjceH32IrozvqeeeKjxKXj7ucUKbKy0nQI6', '', '096388898', 1, 'Hà Nội', 'hDUfGSH0oY', NULL, '2020-12-01 03:29:49', '2020-12-01 03:29:49'),
(14, 'Kassandra Beier', 'nelson70@example.net', '$2y$10$2o/0cYDfZRRtA9ni9fA3HO8VIns8.aG0oDkKlgjsSMmsCyPKl4YBa', '', '096388898', 1, 'Hà Nội', 'Y6ekIIQfHA', NULL, '2020-12-01 03:29:49', '2020-12-01 03:29:49'),
(15, 'Kayden Trantow', 'altenwerth.wendy@example.com', '$2y$10$Oy0mC726iljmkXmyVGmYM.zIJmD9UaSbD0L5Xl/RSjxFxr85v6/SO', '', '096388898', 1, 'Hà Nội', '9a7VUVeacX', NULL, '2020-12-01 03:29:49', '2020-12-01 03:29:49'),
(16, 'Prof. Rigoberto Rodriguez', 'marcella.schamberger@example.net', '$2y$10$5GuEgT2XmFYzA/vgOd4UGezSE.8wWB5tUknVZet6YYZ1EepDnWSaC', '', '096388898', 1, 'Hà Nội', 'OLavLDeeGN', NULL, '2020-12-01 03:29:49', '2020-12-01 03:29:49'),
(17, 'Dr. Eula Bosco', 'trantow.arden@example.org', '$2y$10$4.P3ZM4gW/QAa/MBu3BN4e.Gs1v9P44MCyA/jKFJaja6FIga7k61q', '', '096388898', 1, 'Hà Nội', 'JrPZBhbssV', NULL, '2020-12-01 03:29:49', '2020-12-01 03:29:49'),
(18, 'Danielle Effertz', 'fkonopelski@example.org', '$2y$10$cY/okkUcriKFAyxJa/KpLO5ceqmDbH.nztNd1s59Kx.zdKxOOCHpW', '', '096388898', 1, 'Hà Nội', 'qKlrx079Ox', NULL, '2020-12-01 03:29:49', '2020-12-01 03:29:49'),
(19, 'Dr. Johann Lang', 'bergstrom.conrad@example.com', '$2y$10$zTV83XlAUUhszxmuJuvD8.Qo.lKeEBinsSKMquu/wr4yhYtmgc/X.', '', '096388898', 1, 'Hà Nội', 'd2qkOywEa7', NULL, '2020-12-01 03:29:49', '2020-12-01 03:29:49'),
(20, 'Rahul Orn', 'berry85@example.com', '$2y$10$sKrM5LuOqTMe1MIxh9Z.aOaxdf/vqa/RKjFsCEel0F/8ofy506OPC', '', '096388898', 1, 'Hà Nội', 's7j9arxFfD', NULL, '2020-12-01 03:29:49', '2020-12-01 03:29:49'),
(21, 'Luis Greenholt', 'sandy.hamill@example.org', '$2y$10$24SJm4.uB5meYELWq0UsX.d..6djh127Kgxgz1sq4YAHTegAwmASi', '', '096388898', 1, 'Hà Nội', 'rGjP3YAY9U', NULL, '2020-12-01 03:29:49', '2020-12-01 03:29:49'),
(22, 'Violet Beatty', 'jamaal14@example.net', '$2y$10$iECQJ4yblJ0ilgBCpWzkie/ZDZvLBTFaICq7ng2RPe9q8uMYGEGqa', '', '096388898', 1, 'Hà Nội', 'BvUeJd52rx', NULL, '2020-12-01 03:29:49', '2020-12-01 03:29:49'),
(23, 'Ms. Alberta Ritchie V', 'anader@example.net', '$2y$10$JHqWov9OLDZBznDZutpR1eMQXJGQbGpFEvxrTZqxbF/AV7USFLRjC', '', '096388898', 1, 'Hà Nội', 'V9hBi9IkFO', NULL, '2020-12-01 03:29:49', '2020-12-01 03:29:49'),
(24, 'Lilliana Schinner', 'saige87@example.net', '$2y$10$o1DoMDC0GqTgf8TqN75zjuUnZo6K5k20pPIEFmj0JlMbXhPcv3twa', '', '096388898', 1, 'Hà Nội', 'vhJ16N2yuv', NULL, '2020-12-01 03:29:49', '2020-12-01 03:29:49'),
(25, 'Dean McLaughlin', 'hand.tyshawn@example.net', '$2y$10$gpDjIM.63UNHxgAgy0YXsObwfw3Oz3uOyH5XwkXSFdCTAZtdjukRe', '', '096388898', 1, 'Hà Nội', 'of4Yi1N3up', NULL, '2020-12-01 03:29:49', '2020-12-01 03:29:49'),
(26, 'Brooks Johnson', 'ernie.kuvalis@example.org', '$2y$10$Bv72vEaGeJhSNwfZGzARF.5p6MDAybOuQgtSkMVZLcYw5KWzsG9hq', '', '096388898', 1, 'Hà Nội', 'InFRA5E5Q1', NULL, '2020-12-01 03:29:49', '2020-12-01 03:29:49'),
(27, 'Josephine Schimmel', 'greenfelder.david@example.net', '$2y$10$m6QlNLsfss3tleRIWl9Wi.BGA67Ujb757hshslyXZBM6ev8pZMUKO', '', '096388898', 1, 'Hà Nội', 'ZFLQMLV55m', NULL, '2020-12-01 03:29:49', '2020-12-01 03:29:49'),
(28, 'Destiney Lesch', 'laurine53@example.org', '$2y$10$2KTn0HiXYPRPxomEGyOHLOtYIiynjZ7/q.XZ/0qrSbwckhPNgKeDC', '', '096388898', 1, 'Hà Nội', 'jc1TYmcUc4', NULL, '2020-12-01 03:29:49', '2020-12-01 03:29:49'),
(29, 'Gilberto Weimann', 'tlegros@example.net', '$2y$10$wcNtq6ee4mbjdKKcTMB94ukWh5qfpQ.tEJdMso1uXzzgcgoM4sL8i', '', '096388898', 1, 'Hà Nội', 'UlXAMJtkj1', NULL, '2020-12-01 03:29:49', '2020-12-01 03:29:49'),
(30, 'Albina Ledner', 'wschmeler@example.org', '$2y$10$WSN8XUxtYD8jQtuzh1RaqOibTqE/8FH71ANYePUsFxhk4sRnAcxpi', '', '096388898', 1, 'Hà Nội', 'rtCdvKBTlN', NULL, '2020-12-01 03:29:49', '2020-12-01 03:29:49'),
(31, 'Kenneth Hagenes', 'hipolito.moen@example.com', '$2y$10$l1qJpHS3FJtczdc86m50o.n8qJ6p3e0urffRZasOXlHR8eZbsk2E2', '', '096388898', 1, 'Hà Nội', 'Bnd2glM0O5', NULL, '2020-12-01 03:29:49', '2020-12-01 03:29:49'),
(32, 'Prof. Jaron Cummings', 'kade22@example.com', '$2y$10$RZj5BIlwoF4X4GiYVN/1ruhZKJWmvpmPppTEe9fsqjsvPIO9t6iDu', '', '096388898', 1, 'Hà Nội', 'e3hzYoVf1O', NULL, '2020-12-01 03:29:49', '2020-12-01 03:29:49'),
(33, 'Natalie Nicolas', 'barton.martine@example.com', '$2y$10$n.qhV/hcnZ0FIfqzMPiWlOEuijL8pB9zD4Ow2xUrlmdjPdWBiKPsu', '', '096388898', 1, 'Hà Nội', 'v02F0qsYko', NULL, '2020-12-01 03:29:49', '2020-12-01 03:29:49'),
(34, 'Florence Shields', 'nwest@example.net', '$2y$10$nEa3TXJCrEwORbtQY/YEG.bqOI4br4YBfdQyyyN/i21I/k4IuK3JW', '', '096388898', 1, 'Hà Nội', 'hnTjGUMooN', NULL, '2020-12-01 03:29:49', '2020-12-01 03:29:49'),
(35, 'Nannie Cole', 'faye76@example.org', '$2y$10$J3qp2mVLLrthj44E1vtiJOfmo8f097tewHD5KkqSL6hmg.NQ1WlJu', '', '096388898', 1, 'Hà Nội', '59vN6mSyps', NULL, '2020-12-01 03:29:49', '2020-12-01 03:29:49'),
(36, 'Colin Bayer', 'aurore.lebsack@example.org', '$2y$10$4Qslj.TdTrtRRzJ5/5CqkOTfhp.HztkrT2SF./ZzGt0WmTkcVney2', '', '096388898', 1, 'Hà Nội', 'dy7WIXVpKG', NULL, '2020-12-01 03:29:49', '2020-12-01 03:29:49'),
(37, 'Dr. Carson Rowe Sr.', 'bridie68@example.com', '$2y$10$ESoJRAo7L5nFHcOSnovIHutpqtiStkoLbNBLc3oSYivTMdWIayvlm', '', '096388898', 1, 'Hà Nội', 'YvJ8wtgNVR', NULL, '2020-12-01 03:29:49', '2020-12-01 03:29:49'),
(38, 'Rory Halvorson', 'dariana.wiza@example.org', '$2y$10$jBiXhZLdF2tKzIkSLMFgWOVybjTuMENoIo/ni4SD7spb2yo7RaxJq', '', '096388898', 1, 'Hà Nội', 'Ry3qOHd7yO', NULL, '2020-12-01 03:29:49', '2020-12-01 03:29:49'),
(39, 'Derek Ernser I', 'declan60@example.org', '$2y$10$.crNoYn702.9jpED29PGbuIXdiNtGehhMBcjHb47fJ9Mq0D9FpoC6', '', '096388898', 1, 'Hà Nội', 'q1al1hkLXn', NULL, '2020-12-01 03:29:49', '2020-12-01 03:29:49'),
(40, 'Ms. Abagail Kessler', 'lavonne16@example.org', '$2y$10$AOdFRNa6CTgBimkhn9nxIuGjk7hfnYOEN6tlPq6WxBoR2IDyfPsPO', '', '096388898', 1, 'Hà Nội', 'kIpSjFVUr7', NULL, '2020-12-01 03:29:49', '2020-12-01 03:29:49'),
(41, 'Jarret Bradtke', 'sporer.haskell@example.com', '$2y$10$.I3yeEg1ZJo26jo.qha3HOjXpEj618vn/GD66BihqnfxWYkBsIgau', '', '096388898', 1, 'Hà Nội', 'NqASWmDxvB', NULL, '2020-12-01 03:29:49', '2020-12-01 03:29:49'),
(42, 'Prof. Torrance Legros DVM', 'donnelly.hoyt@example.org', '$2y$10$yAJJSyVwhCDU9lot8fa4SuTXDzSc6kHPLgz1FRks7Bac0NM.J2mw2', '', '096388898', 1, 'Hà Nội', 'hgHw2dgL90', NULL, '2020-12-01 03:29:49', '2020-12-01 03:29:49'),
(43, 'Toni Cummerata', 'batz.lewis@example.org', '$2y$10$s6uQ9OpVes/f.XCTAug9zeMRG2ca1AiUPqhYklFzA9W5iNzz2ryUm', '', '096388898', 1, 'Hà Nội', '3uevrYI1Gr', NULL, '2020-12-01 03:29:49', '2020-12-01 03:29:49'),
(44, 'Efrain Hagenes', 'alejandrin.simonis@example.org', '$2y$10$W9vCWy9yjAgdBle0Zm8Ex.rg2x2vJhKwOUTr7wVm405FJr9OQIt/2', '', '096388898', 1, 'Hà Nội', 'YpGQ6McC16', NULL, '2020-12-01 03:29:49', '2020-12-01 03:29:49'),
(45, 'Ceasar Stoltenberg V', 'effertz.delphia@example.org', '$2y$10$QUoHiaO1lKa4GFeMDFa7J.VnlXLOouoh0Dy/adNXhmgCLLSZRTYNS', '', '096388898', 1, 'Hà Nội', 'zBpgn7u9TD', NULL, '2020-12-01 03:29:49', '2020-12-01 03:29:49'),
(46, 'Alexa Bayer', 'marilou.waelchi@example.net', '$2y$10$MxHSpbVl/pDk3GqX79Igwe2R9SuLWGHYPamBiNKJ2MY7eVMQIAb.i', '', '096388898', 1, 'Hà Nội', 'nmjHy6LRQK', NULL, '2020-12-01 03:29:49', '2020-12-01 03:29:49'),
(47, 'Reinhold Boyle', 'vharvey@example.net', '$2y$10$xZ39kLxgm/DWa6awx7fuyu5IRZt9dE8DdpfVFj6vBPbaaduyMQklm', '', '096388898', 1, 'Hà Nội', 'JB02A0mGrY', NULL, '2020-12-01 03:29:49', '2020-12-01 03:29:49'),
(48, 'Prof. Yadira Cruickshank', 'bennett59@example.org', '$2y$10$LpGGivp2vJk0J/0kPLG3eORHstCsN1vmHLNYo5EV6mrsmKbNizSYe', '', '096388898', 1, 'Hà Nội', 'vNDndz2XEy', NULL, '2020-12-01 03:29:49', '2020-12-01 03:29:49'),
(49, 'Dr. Katherine Upton', 'annamarie38@example.org', '$2y$10$B6tkE0m0N0tEINn3UgfpvuDK6qDEiEXM5hFcBvEC25KHAT85lugDO', '', '096388898', 1, 'Hà Nội', 'I49QjR8qCe', NULL, '2020-12-01 03:29:49', '2020-12-01 03:29:49'),
(50, 'Al Keebler', 'armani30@example.org', '$2y$10$BTY.PwYz.O.fYCUxrtb9UOJlFdig185nWb6CaprRi5r6ckWSJPlAG', '', '096388898', 1, 'Hà Nội', 'PZGpGUTJHW', NULL, '2020-12-01 03:29:49', '2020-12-01 03:29:49'),
(51, 'Phan Như Trang', 'trangpn@gmail.com', 'eyJpdiI6InNMRmt5TWs4c3ZKbmlYTmI0T2wxRFE9PSIsInZhbHVlIjoiSVBZdHZGNlpHRWdPOHBwSDZXeFo5NmxPWHFZQU1haUhqYkN0SkNiOU5Fcz0iLCJtYWMiOiI5Yjg1ZjBhY2M4MTU4ZGEyNjcxZjkzNzRjYzEwZWI1NGQ1ZGJkNTU4ZmI4NjlkNGNmMjc5MmFlNDZjM2EzN2FlIn0=', NULL, '0121454516546', 1, 'Hà Nội', NULL, NULL, '2020-12-05 03:15:00', '2020-12-05 03:15:00'),
(53, 'Admin', 'admin@mail.com', 'eyJpdiI6IkcwMHhGcFNoeGpueG9TUXBRL1MvUXc9PSIsInZhbHVlIjoiQmdHWURidmVZeVRYTThaSjFiZ1M3M2lDV3NvTkRra2YzNm5HWFUwZlJtWT0iLCJtYWMiOiI2YWI3NWIwNjMxM2E3MjEzZGRkZmYwNzdjYmExMTEwNzM4NzcxY2JmMTc5NzRkOWY1ZjVkYWFiNGNkZDg1ZWQxIn0=', NULL, '0123456789', 1, NULL, NULL, NULL, '2021-02-27 22:01:24', '2021-02-27 22:01:24'),
(55, 'test', 'test@gmail.com', '12345678', NULL, '0123456789', 1, NULL, NULL, NULL, '2021-03-01 00:34:13', '2021-03-01 00:34:13'),
(57, 'Nguyen Van b', 'bbb@gmail.com', 'eyJpdiI6ImZCK2xmTDd3QzAwSVpkSzEvT05MeWc9PSIsInZhbHVlIjoiUTgrdy9YY21Fa3F3SGhoRFJEbmV4dz09IiwibWFjIjoiY2NiNzQyZTcxOWJmZjk3ODgyMDMwYmEwM2NiMjg4OGFmNzdjYzQ5ZTMwZjZmNzMwYmY2Zjc4MjJmYjBhODQ2YiJ9', NULL, '0987654321', 1, 'Ha noi', NULL, NULL, '2021-03-05 05:56:09', '2021-03-05 21:21:23'),
(58, 'Nguyen Van c', 'ccc@gmail.com', 'eyJpdiI6IjJGQThkdjRJVk1XM0t3Smt3VlZvZ3c9PSIsInZhbHVlIjoiWUY5REtvelhDQjU4R0hXYlA2QisvUT09IiwibWFjIjoiOGQwMmE5MzU4ZDI5ZWM1OTY0ZTM1YWY5YmY3Y2I0OThmM2JjYzE2NTJlYTJiY2EwZTE3YmU4NDE4NzEyM2E3MSJ9', NULL, '0123456789', 1, 'Ha noi', NULL, NULL, '2021-03-06 00:52:36', '2021-03-06 00:52:36');

--
-- Chỉ mục cho các bảng đã đổ
--

--
-- Chỉ mục cho bảng `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Chỉ mục cho bảng `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`);

--
-- Chỉ mục cho bảng `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Chỉ mục cho bảng `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`);

--
-- Chỉ mục cho bảng `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Chỉ mục cho bảng `posts`
--
ALTER TABLE `posts`
  ADD PRIMARY KEY (`id`);

--
-- Chỉ mục cho bảng `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Chỉ mục cho bảng `product_images`
--
ALTER TABLE `product_images`
  ADD PRIMARY KEY (`id`);

--
-- Chỉ mục cho bảng `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`),
  ADD KEY `users_email_index` (`email`),
  ADD KEY `users_phone_index` (`phone`);

--
-- AUTO_INCREMENT cho các bảng đã đổ
--

--
-- AUTO_INCREMENT cho bảng `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT cho bảng `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT cho bảng `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=76;

--
-- AUTO_INCREMENT cho bảng `orders`
--
ALTER TABLE `orders`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT cho bảng `posts`
--
ALTER TABLE `posts`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT cho bảng `products`
--
ALTER TABLE `products`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=56;

--
-- AUTO_INCREMENT cho bảng `product_images`
--
ALTER TABLE `product_images`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT cho bảng `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=59;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
